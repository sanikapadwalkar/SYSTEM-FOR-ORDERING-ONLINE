# OnlineFoodOrderingSystem


This Project is Made for Future ready talent offered by microsoft azure https://onlinehealthyfoodorderingsystem.azurewebsites.net

My project title is "Online Healthy Food Ordering System".This is a Web application developing to provide complete solutions for vendors/owner as well as customers through a single get way using the internet.It will enable vendors/Owner to setup online foods, customer to browse through the shop and purchase them online without having to visit the shop physically in this pandemic situation.

Microsoft Azure is great platform to use and it has many services and features. In this project I used azure app service and web apps for deploying My code ✔Azure App service

Ion microsoft azure we ahould login using using our credentials ,we should have free trail account or we can claim student account subscription After login in App Service click on Create Appservice and then fill the nedded details as follows.....

create resource group resource group subscription plan name of website u want to deploy monitoring deafult values tags deafault review and create create

Then in Deployment section

deployment centre >settings fill the needed details like repository name URL Branch

Then You can deploy website in overview when you click on URL you can see youre websiteDeployment_centre Overview



![image](https://user-images.githubusercontent.com/79084462/150804618-f9ece406-1aed-4238-8959-511d3389d242.png)


![image](https://user-images.githubusercontent.com/79084462/150805541-b7c87991-6f08-40ef-81e2-1e659f581619.png)

THIS IS VIDEO URL DEMO OF MY WEBSITE DEPLOYMENT IT IS SAMPLE VIDEO >>>
